export default function Booking() {
    return (
        <main>
            <div>
                Booking Page
            </div>
        </main>
    );
}